# CodeCraft VirtualModule — Level 0 Contract

Document: CodeCraft Model-First README  
Document type: `framework`  
Component: `virtual`  
Component version: `3.0.1.1`  
Scope: `device/common/virtual/`  
Applies to: `CodeCraft_virtual_module_ddr.json`  
Authority: Informational; the VirtualModule DDR and golden source are authoritative  
Portability: Reusable Level 0 component  
Projection: Consume and exclude this README; copy the selected golden source through `device/lib/`  
Platform dependency: Selected Level 0 implementation  
Status: Golden
Copyright: © 2026 Roman Kiss, rkiss@pathcom.com  
Development: With assistance from ChatGPT and CodeCraft

> This README documents the Level 0 usage contract. It must not redefine or extend the golden implementation. When this document conflicts with the DDR or golden source, the DDR and golden source are authoritative.

## Purpose

VirtualModule is the Level 0 base class and container contract used by CodeCraft business modules. It owns chain routing, command dispatch, cross-module subscriptions, event delivery, context propagation, lifecycle and instrumentation.

## Component Boundaries

VirtualModule provides infrastructure only. It declares no concrete business command, hardware driver, board binding, module instance or chain position. Derived modules register their own handlers and use the inherited API.

## DDR File Structure

```text
device/common/virtual/
├── CodeCraft_virtual_module_ddr.json
└── README.md
```

## DDR Map

```text
CodeCraft_virtual_module_ddr.json
|
+-- Design
|   +-- declaration and golden source
|   +-- lifecycle and delegates
|   +-- messaging and handlers
|   +-- subscription identity and delivery modes
|   +-- filter grammar and topic matching
|   +-- business-module API and extensions
|   `-- Level 0 invariants
|
+-- Deployment
|   +-- selected platform context
|   +-- required namespaces
|   `-- required types
|
`-- Runtime
    +-- instrumentation format
    +-- response formats
    `-- byte-identical source policy
```

## Public Contract

The principal business-module surface is `RegisterHandler`, `Publish`, `EmitEvent`, subscription operations, topic switches, filter evaluation, tracing and `MessageFormat`. `ChainHead` is the only globally retained container entry after composition; `ForwardTarget` defines the ordered topology.

Subscription identity is producer plus consumer endpoint plus topic pattern plus delivery mode. Repeating `SUB` for the same identity updates only its filter expression. Delivery modes are `PUSH`, `PUSH_PULL` and `PULL`.

The legacy `int msgId` signature carries a 32-bit context. Traces and response formats render it as eight uppercase hexadecimal characters.

## Agility and Portability

Derived modules assume no fixed predecessor or successor. Runtime composition owns instance count, suffix, order and lifecycle. Cross-subscriptions are stored on the event producer; the container head is not a global event bus.

## Generation or Projection

The DDR is consumed as a usage contract and excluded from Package 2. The selected golden `VirtualModule.cs` implementation is copied byte-identically from `device/lib/`. A generator must not recreate Level 0 functionality inside a business module.

## Examples

Examples and AppLog syntax belong to component or package documentation. They never extend the Level 0 grammar declared by the DDR.

## Validation

Validate the immutable DDR hash, the selected golden-source hash, exact public signatures, subscription semantics, response formats and context instrumentation before generating business modules.

## Known Limitations / TODO

Filter references using `@scope:name` remain reserved and currently return `EFILTERREF:UNSUPPORTED`.

## Changelog

### 3.0.1.1

- Added the standard copyright declaration to the immutable DDR metadata; Level 0 behavior and golden `VirtualModule.cs` remain unchanged.

### 3.0.1

- Golden Level 0 usage contract aligned with the tested VirtualModule implementation.
- Documents current context rendering, subscription overwrite identity, SUBLIST FAN-IN and numeric filters.
