# SYS module

Reusable SYS service contract: NEO, LED, BUTTON, FLASH and TMR/WDG. See the adjacent module and AT DDR for authoritative semantics. No application actions are selected.
