# CodeCraft_package1_sys@3.1.5.14

Standalone Model-First package with one module type (SYS) and one runtime instance (sys).

Generate the full Code-First target from device/entry.json and the selected module DDR. The explicit container ID is 8; assign a unique ID in 1..127 when deploying multiple containers. No external business module is required.

SYS retains NEO, LED, BUTTON, FLASH and TMR/WDG service contracts and their selected physical bindings. Application-specific event actions and startup subscriptions are absent.

Shared golden library bytes and the separate deployment override are unchanged. Common library protocol types do not select or require a business module.

Validation: JSON syntax, package references, module fingerprint, bypass hashes and single-instance topology checked. Code-First generation, compilation and hardware testing have not been performed for this derived state.
