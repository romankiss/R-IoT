# CodeCraft_package1_sys_empty@3.1.5.14

Model-First package with SYS and EMPTY module types. Runtime chain: SYS -> EMPTY0 -> EMPTY1. Both EMPTY instances reuse one module type.

Generate the full Code-First target from device/entry.json and the selected module DDR. The explicit container ID is 8; assign a unique ID in 1..127 when deploying multiple containers. No external business module is required.

SYS retains NEO, LED, BUTTON, FLASH and TMR/WDG service contracts and their selected physical bindings. Application-specific event actions and startup subscriptions are absent.

Shared golden library bytes and the separate deployment override are unchanged. Common library protocol types do not select or require a business module.

Validation: JSON syntax, package references, module fingerprint, bypass hashes and three-instance topology checked. Code-First generation, compilation and hardware testing have not been performed for this derived state.
