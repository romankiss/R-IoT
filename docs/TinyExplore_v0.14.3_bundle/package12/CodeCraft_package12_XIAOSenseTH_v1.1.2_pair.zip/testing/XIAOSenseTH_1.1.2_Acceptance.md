# XIAOSenseTH 1.1.2 focused check

1. Boot and check the startup banner for XIAOSenseTH 1.1.2.
2. Run `AT+PUBA=CAM,CAPTURE,0x124,LOG|EVENT|DATA`. Check JPEG logging, CAPTURE/DONE delivery and async_result body truncation.
3. For transport coverage, attach a /RESULT consumer and check it receives the full payload.
