# XIAOSenseTH 1.1.2

**VERIFIED** for the scoped golden release. The startup banner is configured for 1.1.2. Synchronous and asynchronous result traces abbreviate oversized data bodies.

See `validation/XIAOSenseTH_1.1.2_Acceptance.md` for device evidence and its limits.
