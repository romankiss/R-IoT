# XIAOSenseTH 1.1.2 delta acceptance

The v1.1.1 owner acceptance is the verified baseline. This revision changes two production files.

- VirtualModule.cs changes one async_result trace argument. The owner tested the exact one-line correction on the device.
- Program.cs changes only the startup display literal to 1.1.2. The exact change was checked statically. A fresh boot of the repackaged v1.1.2 archive was not performed.
- /RESULT continues to emit the original response in code. Full payload delivery to a /RESULT subscriber was not separately measured.

## Device trace

Command `AT+PUBA=CAM,CAPTURE,0x124,LOG|EVENT|DATA`.

```text
[20:11:22.490] [TRACE] CAM:async_execute ctx=00000124 cmd=CAPTURE args=LOG|EVENT|DATA
[20:11:22.507] [TRACE] CAM:capture_image ctx=00000124 JPEG[5227]
[20:11:22.530] [TRACE] CAM:emit_event ctx=00000124 topic=CAM/CAPTURE/DONE
[20:11:22.538] [TRACE] SYS:deliver_event ctx=00000124 topic=CAM/CAPTURE/DONE filter='$arg1>0|$tag=FLASH_Write' mode=PUSH
[20:11:22.650] [TRACE] SYS:handler_event ctx=00000124 topic=CAM/CAPTURE/DONE filter='$arg1>0|$tag=FLASH_Write' args=3,5227,Qvga,[TRUNCATED at 128]
[20:11:22.660] [TRACE] SYS:handler_event ctx=00000124 topic=CAM/CAPTURE/DONE filter='Write' args=3,5227,Qvga,[TRUNCATED at 128]
[20:11:22.692] [TRACE] CAM:async_result ctx=00000124 cmd=CAPTURE result=+DATA:00000124,CAM:capture,seq=3,length=5227,frameSize=Qvga,body=[TRUNCATED at 128]
```
