# XIAOSenseTH 1.1.1 owner acceptance

Status **VERIFIED**, scoped Code-First acceptance. Target **XIAO ESP32S3 Sense**.

The owner reported compiler OK, flasher OK and owner tests OK after rerunning Placer. After receiving the independent AEP result, the owner explicitly confirmed that the evidence was sufficient for VERIFIED and supplied the LoRa trace below.

## Owner startup and CAM RKB

- 19:15:30.142 FLASH OPEN returned +OK. LORA OPEN and SETUP returned +OK. All modules reached READY at 19:15:31.593.
- 19:18:01 and 19:18:36 CAM CAPTURE LOG|EVENT and LOG|EVENT|DATA reached the SYS PUSH subscription and FLASH resource handler. The caller received the JPEG body for seq=5. Both handler and route_ok showed [TRUNCATED at 128].
- The startup banner prints 1.1.0 from the retained Program.cs. Archive identity and acceptance are v1.1.1.

## Independent AEP test after deployment

CAM CAPTURE DATA|EVENT returned QVGA seq=6. JPEG decoding confirmed 320 × 240 and 5,227 bytes, matching the declared length. AEP completed receipt ACK on revision 8248 in IDLE.

JPEG SHA-256 `f3c494db8c72ff615a1124759cbb29f3106cee5810eddb07559cab898288eb27`.

```text
[19:23:33.443] [TRACE] SYS:deliver_event ctx=00000172 topic=CAM/CAPTURE/DONE filter='$arg1>0|$tag=FLASH_Write' mode=PUSH
[19:23:33.453] [TRACE] SYS:handler_event ctx=00000172 topic=CAM/CAPTURE/DONE filter='$arg1>0|$tag=FLASH_Write' args=6,5227,Qvga,[TRUNCATED at 128]
[19:23:33.463] [TRACE] SYS:handler_event ctx=00000172 topic=CAM/CAPTURE/DONE filter='Write' args=6,5227,Qvga,[TRUNCATED at 128]
[19:23:33.492] [TRACE] CAM:route_ok ctx=00000172 cmd=CAPTURE result=+DATA:00000172,CAM:capture,seq=6,length=5227,frameSize=Qvga,body=[TRUNCATED at 128]
```

## Owner LoRa RKB

```text
[19:31:43.940] [TRACE] LORA:crosssub_add ctx=00000911 consumer=LORA topic=/QRX/PACK filter='ACK_PING*' mode=PUSH
[19:31:43.961] [TRACE] LORA:route_ok ctx=00000911 cmd=SEND_ACK result=+OK:00000911,LORA:PacketEnqueued
[19:31:43.970] [TRACE] LORA:QueueTX ctx=00000911 count=0, Raw: 13-08-88-FF-FF-00-00-09-11-00-50-49-4E-47-20-23-31-32-33-34-34
[19:31:49.262] [TRACE] LORA:handler_event ctx=00000000 topic=LORA/QRX/PACK filter='ACK_PING*' args=0900,0888,-72,5,ACK_PING #1234
[19:31:52.132] [TRACE] LORA:handler_event ctx=00000000 topic=LORA/QRX/PACK filter='ACK_PING*' args=5000,0888,-57,22,ACK_PING #1234
```

The receiver delivered two matching reply events. RX contexts are zero, so the RKB supports payload matching, without an end-to-end context match.

## Limits

Acceptance is owner-scoped. One AppLog Failed to fetch occurred with undetermined cause. Later /log?-10 reads and the independent AEP test succeeded. The FLASH event reached its handler; a physical write was outside this test. A fresh WDG or TH-specific trace, physical BUTTON/LED/NEO activation, and async capture are outside the documented evidence. Resource dispatch for BUTTON/LED/NEO/TMR was tested earlier on the development firmware. The proposed HTML preview aspect-ratio change was discussed separately from the tested archive.
