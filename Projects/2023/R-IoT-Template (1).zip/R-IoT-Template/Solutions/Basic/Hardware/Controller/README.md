**References:**

<p style="display:inline-block;">
  <img  width="10%" src="https://github.com/romankiss/R-IoT/assets/30365471/40ae9537-c80b-49c5-803d-bfe5a858fb83">
  <a href="https://shop.m5stack.com/collections/m5-controllers/products/atom-lite-esp32-development-kit">ATOM Lite ESP32 IoT Development Kit.</a>
  <br/><br/>
 <img width="10%" src="https://github.com/romankiss/R-IoT/assets/30365471/dab71889-6844-4671-a300-f376cfcb8c7f">
   <a href="https://shop.m5stack.com/products/atomic-portabc-extension-base"> ATOMIC PortABC Extension Base</a>
  <br/><br/>
  <img width="10%" src="https://github.com/romankiss/R-IoT/assets/30365471/52fe0b5a-8dcf-41d2-8f07-c35b4c9451d5">
   <a href="https://docs.m5stack.com/en/unit/AtomPortABC"> Example of usage</a>
  <br/><br/>
</p>


<br/><br/><br/><br/>

![image](https://github.com/romankiss/R-IoT/assets/30365471/cebffa4c-8338-4030-a1e4-8667eed18f91)

<br/>
<br/>


![image](https://github.com/romankiss/R-IoT/assets/30365471/10891be1-0619-4700-9b1e-aa733e7c5b4a)

<br/>
<br/>

![image](https://github.com/romankiss/R-IoT/assets/30365471/0de638dc-9079-4741-b5ac-0011a7cef145)


