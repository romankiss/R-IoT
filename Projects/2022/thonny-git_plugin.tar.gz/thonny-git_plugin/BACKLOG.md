
# BACKLOG

- 


# OPEN ISSUES

refer to [issues](https://github.com/kr-g/thonny-gitonic/issues)


# LIMITATIONS

- 
 

