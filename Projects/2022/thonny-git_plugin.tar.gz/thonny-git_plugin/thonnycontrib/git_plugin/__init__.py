import os

VERSION = "v0.0.3-a"

# import subprocess

from tkinter import messagebox

from thonny import get_workbench
from thonny.ui_utils import select_sequence


def hello():
    showinfo("Hello!", "Thonny rules!")

def load_plugin():
    get_workbench().add_command(command_id="hello",
                                menu_name="tools",
                                command_label="Hello!",
                                handler=hello)
