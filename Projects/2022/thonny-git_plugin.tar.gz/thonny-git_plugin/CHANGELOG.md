
# Changelog


## next version v0.0.3 - ???

- 


## version v0.0.2 - 20220522

- fix entry point in setup py
- fix plugin source in wheel
- 


## version v0.0.1 - 20211107

- first version 
- 