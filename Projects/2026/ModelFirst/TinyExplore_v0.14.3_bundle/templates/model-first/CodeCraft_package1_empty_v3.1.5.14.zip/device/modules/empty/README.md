# EMPTY module

Reusable module with INFO, ECHO and LOOPBACK commands, a mandatory metadata connector and no physical resources. See the adjacent module and AT DDR for authoritative semantics.
