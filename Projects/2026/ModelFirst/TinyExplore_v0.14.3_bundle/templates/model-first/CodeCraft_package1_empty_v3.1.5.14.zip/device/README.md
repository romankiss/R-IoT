# CodeCraft_package1_empty@3.1.5.14

Standalone Model-First package with one module type (EMPTY) and one runtime instance (empty0).

Generate the full Code-First target from device/entry.json and the selected module DDR. The explicit container ID is 8; assign a unique ID in 1..127 when deploying multiple containers. No external business module is required.

EMPTY0 has no physical resource or hardware driver binding. Activation has no resource commands or hardware indicators.

Shared golden library bytes and the separate deployment override are unchanged. Common library protocol types do not select or require a business module.

Validation: JSON syntax, package references, module fingerprint, bypass hashes and single-instance topology checked. Code-First generation, compilation and hardware testing have not been performed for this derived state.
