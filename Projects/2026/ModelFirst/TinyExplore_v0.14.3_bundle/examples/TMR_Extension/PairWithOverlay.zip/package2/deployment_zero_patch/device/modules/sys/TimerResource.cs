// CodeCraft generated artifact
// Source: CodeCraft_package1_PeriodicTMR@1.0.0
// Contract: device/modules/sys/CodeCraft_sys_module.json#/Design/resources/TMR
// Copyright © 2026 Roman Kiss, rkiss@pathcom.com
using System;
using System.Collections;
using System.Diagnostics;
using System.Threading;
using System.Text;
using CodeCraft.Common;
namespace CodeCraft.Modules.Sys
{
    public partial class SysModule
    {
        private int timerCapacity;
        private readonly object timerSync = new object();
        private readonly Hashtable namedTimers = new Hashtable();
        private readonly Hashtable watchdogRoutes = new Hashtable();
        private readonly Hashtable watchdogDeliveries = new Hashtable();
        private readonly Stopwatch timerClock = Stopwatch.StartNew();
        private sealed class TimerEntry
        {
            internal string Id, Tag, State, Consumer = "", Type = "TMR", ExpectedReply = "", Action = "";
            internal int DelayMs, Context, PeriodMs;
            internal long Run;
            internal long ExpirationCount;
            internal long Deadline;
            internal bool Delivering;
            internal Timer Timer;
        }
        private static bool ValidTimerId(string id)
        {
            if (id == null || id.Length == 0 || id.Length > 64) return false;
            for (int i = 0; i < id.Length; i++)
            {
                char c = id[i];
                if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                    (c >= '0' && c <= '9') || c == '_' || c == '-')) return false;
            }
            return true;
        }
        private static bool ValidTimerTag(string tag)
        {
            for (int i = 0; i < tag.Length; i++)
                if (tag[i] < 32 || (tag[i] >= 127 && tag[i] <= 159) || tag[i] == ',' || tag[i] == '|') return false;
            return true;
        }

        private static bool ValidConsumer(string consumer)
        {
            if (string.IsNullOrEmpty(consumer)) return false;
            for (int i = 0; i < consumer.Length; i++)
            {
                char c = consumer[i];
                if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                    (c >= '0' && c <= '9') || c == '_')) return false;
            }
            return true;
        }
        // All callers hold timerSync. Route mutation never invokes a consumer.
        private string EnsureWatchdogRoute(string consumer, int context)
        {
            if (watchdogRoutes.Contains(consumer)) return null;
            string listing = CrossSubscriptionList(consumer, Topics.WatchdogExpired, "PUSH", context);
            if (listing == null || listing.IndexOf("+OK:") != 0) return "ESUB";
            if (listing.IndexOf(",count=0 []") < 0) return "ESUBOWNED";
            string response = CrossSubscribe(consumer, Topics.WatchdogExpired, "$arg2=" + consumer, "PUSH", context);
            if (response == null || response.IndexOf("+OK:") != 0)
            { TraceLog(AtGroup, "wdg_sub", context, response ?? "No response"); return "ESUB"; }
            // Managed routes are exclusively resource-owned until last demand ends.
            // External SUB/UNSUB/TOGGLE/SWITCH edits during this lifetime are unsupported.
            watchdogRoutes[consumer] = true;
            return null;
        }
        private void ReconcileWatchdogRoutes(int context)
        {
            ArrayList unused = new ArrayList();
            foreach (DictionaryEntry route in watchdogRoutes)
            {
                string consumer = (string)route.Key;
                bool needed = watchdogDeliveries.Contains(consumer) && (int)watchdogDeliveries[consumer] > 0;
                foreach (DictionaryEntry item in namedTimers)
                {
                    TimerEntry e = (TimerEntry)item.Value;
                    if (e.Type == "WDG" && e.Consumer == consumer && (e.State == "active" || e.Delivering)) needed = true;
                }
                if (!needed) unused.Add(consumer);
            }
            for (int i = 0; i < unused.Count; i++)
            {
                string consumer = (string)unused[i];
                string response = CrossUnsubscribe(consumer, Topics.WatchdogExpired, "PUSH", context);
                if (response != null && (response.IndexOf("+OK:") == 0 || response.IndexOf(",ENOTFOUND") >= 0))
                    watchdogRoutes.Remove(consumer);
                else TraceLog(AtGroup, "wdg_unsub", context, response ?? "No response");
            }
        }
        private void DisposeTimer(TimerEntry e)
        {
            try { e.Timer.Dispose(); }
            catch (Exception ex) { TraceLog(AtGroup, "tmr_dispose", e.Context, ex.Message); }
        }
        private int CloseAllTimers()
        {
            lock (timerSync)
            {
                int count = 0;
                ArrayList remove = new ArrayList();
                foreach (DictionaryEntry item in namedTimers)
                {
                    TimerEntry e = (TimerEntry)item.Value;
                    if (e.PeriodMs > 0 && e.State == "closed") continue;
                    count++;
                    e.Run++; e.State = "closed"; e.ExpectedReply = ""; DisposeTimer(e);
                    // Periodic in-flight IDs retain a tombstone in the existing pool.
                    if (e.PeriodMs == 0 || !e.Delivering) remove.Add(e.Id);
                }
                for (int i = 0; i < remove.Count; i++) namedTimers.Remove(remove[i]);
                ReconcileWatchdogRoutes(0); return count;
            }
        }
        private TimerEntry AllocateTimer(string id)
        {
            TimerEntry entry = null;
            if (namedTimers.Count >= timerCapacity)
            {
                foreach (DictionaryEntry item in namedTimers)
                {
                    TimerEntry candidate = (TimerEntry)item.Value;
                    if ((candidate.State == "idle" || candidate.State == "expired") && !candidate.Delivering &&
                        (entry == null || TimerIdCompare(candidate.Id, entry.Id) < 0)) entry = candidate;
                }
                if (entry == null) return null;
                namedTimers.Remove(entry.Id);
            }
            else
            {
                entry = new TimerEntry();
                entry.Timer = new Timer(TimerExpired, entry, Timeout.Infinite, Timeout.Infinite);
            }
            entry.Id = id; entry.State = "idle"; entry.Type = "TMR"; entry.Consumer = "";
            entry.Tag = ""; entry.ExpectedReply = ""; entry.Action = "";
            entry.PeriodMs = 0; entry.Run++; entry.Deadline = 0; entry.Delivering = false;
            entry.DelayMs = 0; entry.Context = 0; entry.ExpirationCount = 0;
            namedTimers.Add(id, entry); return entry;
        }
        private void TimerExpired(object state)
        {
            TimerEntry e = (TimerEntry)state;
            bool committed = false, periodic = false; long run = 0, expirationCount = 0;
            string consumer = ""; int context = 0;
            try
            {
                string id, tag, type;
                lock (timerSync)
                {
                    if (!object.ReferenceEquals(namedTimers[e.Id], e) || e.State != "active") return;
                    if (e.PeriodMs > 0 && e.Delivering) return;
                    long remaining = e.Deadline - timerClock.ElapsedMilliseconds;
                    if (remaining > 0)
                    {
                        if (!e.Timer.Change((int)remaining, Timeout.Infinite)) throw new InvalidOperationException("Timer.Change returned false");
                        return;
                    }
                    periodic = e.PeriodMs > 0; run = e.Run;
                    // Preserve legacy commitment before EmitEvent; periodic stays active.
                    if (!periodic) e.State = "expired";
                    e.Delivering = true; committed = true;
                    // Count committed expirations, regardless of subscriber interest.
                    if (periodic) expirationCount = ++e.ExpirationCount;
                    id = e.Id; tag = e.Tag; context = e.Context; consumer = e.Consumer; type = e.Type;
                    if (type == "WDG") watchdogDeliveries[consumer] = watchdogDeliveries.Contains(consumer) ? (int)watchdogDeliveries[consumer] + 1 : 1;
                }
                if (type == "WDG") EmitEvent(Topics.WatchdogExpired, context, id, tag, consumer);
                else EmitEvent(Topics.TimerExpired, context, id, tag,
                    periodic ? "mode=PER" : "mode=ONE",
                    "count=" + expirationCount);
            }
            catch (Exception ex)
            {
                lock (timerSync)
                {
                    if (!committed && object.ReferenceEquals(namedTimers[e.Id], e) && e.State == "active")
                    { e.State = "closed"; namedTimers.Remove(e.Id); DisposeTimer(e); }
                }
                TraceLog(AtGroup, "tmr_callback", e.Context, ex.Message);
            }
            finally
            {
                lock (timerSync)
                {
                    if (committed)
                    {
                        e.Delivering = false;
                        if (periodic && object.ReferenceEquals(namedTimers[e.Id], e))
                        {
                            if (e.State == "closed") namedTimers.Remove(e.Id);
                            else if (e.State == "active" && e.Run == run)
                            {
                                try
                                {
                                    long now = timerClock.ElapsedMilliseconds;
                                    // Advance on the original cadence, strictly past completion.
                                    long next = NextPeriodicSlot(e.Deadline, e.PeriodMs, now);
                                    if (!e.Timer.Change((int)(next - now), Timeout.Infinite))
                                        throw new InvalidOperationException("Timer.Change returned false");
                                    e.Deadline = next;
                                }
                                catch (Exception ex)
                                {
                                    e.Run++; e.State = "closed"; namedTimers.Remove(e.Id); DisposeTimer(e);
                                    TraceLog(AtGroup, "tmr_periodic_rearm", context, ex.Message);
                                }
                            }
                        }
                        if (consumer != "")
                        {
                            int count = (int)watchdogDeliveries[consumer] - 1;
                            if (count == 0) watchdogDeliveries.Remove(consumer); else watchdogDeliveries[consumer] = count;
                        }
                    }
                    ReconcileWatchdogRoutes(context);
                }
            }
        }
        private static long NextPeriodicSlot(long deadline, int period, long now)
        {
            if (deadline > now) return deadline;
            return deadline + ((now - deadline) / period + 1) * period;
        }
        private static bool ParsePeriod(string text, out int value)
        {
            // Period is digits only; baseline delay parsing remains unchanged.
            value = 0;
            if (string.IsNullOrEmpty(text)) return false;
            for (int i = 0; i < text.Length; i++)
            {
                int digit = text[i] - '0';
                if (digit < 0 || digit > 9 || value > (int.MaxValue - digit) / 10) return false;
                value = value * 10 + digit;
            }
            return value > 0;
        }
        private static bool ValidReply(string text)
        {
            if (text == null) return false;
            for (int i = 0; i < text.Length; i++)
                if (text[i] == ',' || text[i] < 32 || (text[i] >= 127 && text[i] <= 159)) return false;
            return true;
        }
        // Payload context syntax is decimal or explicit hexadecimal; never the envelope's
        // canonical-eight-character heuristic or WiFiAgent's legacy 24-bit restriction.
        private static bool ParseSupervisedContext(string text, out int value)
        {
            value = 0;
            if (string.IsNullOrEmpty(text)) return false;
            bool hex = text.Length > 2 && text[0] == '0' && (text[1] == 'x' || text[1] == 'X');
            int start = hex ? 2 : 0, radix = hex ? 16 : 10;
            for (int i = start; i < text.Length; i++)
            {
                char c = text[i]; int digit;
                if (c >= '0' && c <= '9') digit = c - '0';
                else if (hex && c >= 'a' && c <= 'f') digit = c - 'a' + 10;
                else if (hex && c >= 'A' && c <= 'F') digit = c - 'A' + 10;
                else return false;
                if (digit >= radix || value > (int.MaxValue - digit) / radix) return false;
                value = value * radix + digit;
            }
            return true;
        }
        // Called only by TimerHandler while timerSync is held. Returns a status;
        // application action tokens remain opaque data here.
        private string ConfirmWatchdog(int commandContext, string[] args)
        {
            if (args.Length != 6) return Error(commandContext, "EARGS");
            if (!ValidTimerId(args[1])) return Error(commandContext, "EID");
            int supervisedContext;
            if (!ParseSupervisedContext(args[2], out supervisedContext)) return Error(commandContext, "ERANGE");
            if (!ValidConsumer(args[3])) return Error(commandContext, "ECONSUMER");
            if (!ValidTimerId(args[4])) return Error(commandContext, "EACTION");
            if (!ValidReply(args[5])) return Error(commandContext, "EREPLY");
            TimerEntry e = (TimerEntry)namedTimers[args[1]];
            string reason = "";
            if (e == null || e.Type != "WDG" || e.State == "idle" || e.Delivering) reason = "not_pending";
            else if (e.State == "expired" || timerClock.ElapsedMilliseconds >= e.Deadline) reason = "expired";
            else if (e.ExpectedReply == "") reason = "not_correlated";
            else if (supervisedContext == 0 || e.Context != supervisedContext) reason = "ctx_mismatch";
            else if (e.Consumer != args[3]) reason = "consumer_mismatch";
            else if (e.Action != args[4]) reason = "action_mismatch";
            else if (e.ExpectedReply != args[5]) reason = "reply_mismatch";
            string prefix = "tmr,wdg_confirm," + args[1] + ",";
            if (reason != "") return MessageFormat.BuildData(AtGroup, commandContext, prefix + "ignored,reason=" + reason);
            try
            {
                if (!e.Timer.Change(Timeout.Infinite, Timeout.Infinite)) return Error(commandContext, "EPLATFORM");
            }
            catch (Exception ex) { TraceLog(AtGroup, "wdg_complete", commandContext, ex.Message); return Error(commandContext, "EPLATFORM"); }
            e.State = "idle";
            // Keep correlation configuration for explicit START/RESTART, while idle
            // prevents duplicate acceptance. A fresh WDG or CLOSE replaces it.
            ReconcileWatchdogRoutes(commandContext);
            return MessageFormat.BuildData(AtGroup, commandContext, prefix + "accepted");
        }
        private string TimerSummary(int active)
        { return "tmr,activeCount=" + active + ",poolCount=" + namedTimers.Count + ",capacity=" + timerCapacity; }
        private string TimerHandler(string cmd, int msgId, string[] args)
        {
            if (args == null || args.Length == 0) return Error(msgId, "EARGS");
            string op = args[0].ToUpper();
            if (op == "CLOSE" && args.Length == 2 && args[1] == "*") return Ok(msgId, "tmr,close,*,count=" + CloseAllTimers());
            lock (timerSync)
            {
                if (op == "WDG_CONFIRM") return ConfirmWatchdog(msgId, args);
                if (op == "INFO" || op == "LIST")
                {
                    if (args.Length > 2) return Error(msgId, "EARGS");
                    bool names = op == "LIST" && args.Length == 2 && args[1].ToUpper() == "NAMES";
                    bool all = op == "LIST" && args.Length == 2 && args[1].ToUpper() == "ALL";
                    if (op == "LIST" && args.Length == 2 && !names && !all) return Error(msgId, "EOPERATION");
                    int active = 0;
                    foreach (DictionaryEntry item in namedTimers) if (((TimerEntry)item.Value).State == "active") active++;
                    if (op == "INFO")
                    {
                        if (args.Length == 1) return MessageFormat.BuildData(AtGroup, msgId, TimerSummary(active));
                        if (!ValidTimerId(args[1])) return Error(msgId, "EID");
                        TimerEntry detail = (TimerEntry)namedTimers[args[1]];
                        if (detail == null) return Error(msgId, "ENOTFOUND");
                        long snapshotNow = timerClock.ElapsedMilliseconds;
                        long snapshotDeadline = detail.PeriodMs > 0 && detail.Delivering && detail.State == "active"
                            ? NextPeriodicSlot(detail.Deadline, detail.PeriodMs, snapshotNow) : detail.Deadline;
                        long remaining = detail.State == "active" ? snapshotDeadline - snapshotNow : 0;
                        if (remaining < 0) remaining = 0;
                        return MessageFormat.BuildData(AtGroup, msgId, "tmr,id=" + detail.Id + ",state=" + detail.State + ",delayMs=" + detail.DelayMs +
                            ",type=" + detail.Type + ",consumer=" + detail.Consumer + ",remainingMs=" + remaining + ",tag=" + detail.Tag +
                            ",context=" + detail.Context.ToString("X8") + (detail.ExpectedReply == "" ? "" : ",expectedReply=" + detail.ExpectedReply) +
                            (detail.PeriodMs > 0 ? ",mode=PERIODIC,periodMs=" + detail.PeriodMs + ",delivering=" + detail.Delivering.ToString().ToLower() : ""));
                    }
                    string[] ids = new string[all ? namedTimers.Count : active]; string[] rows = new string[ids.Length]; int index = 0;
                    foreach (DictionaryEntry item in namedTimers)
                    {
                        TimerEntry listed = (TimerEntry)item.Value; if (!all && listed.State != "active") continue;
                        ids[index] = listed.Id; rows[index++] = names ? listed.Id : listed.Id + "," + listed.State + "," + listed.DelayMs +
                            (listed.PeriodMs > 0 ? ",PERIODIC," + listed.PeriodMs : "");
                    }
                    for (int i = 1; i < ids.Length; i++)
                        for (int j = i; j > 0 && TimerIdCompare(ids[j - 1], ids[j]) > 0; j--)
                        {
                            string id = ids[j]; ids[j] = ids[j - 1]; ids[j - 1] = id;
                            string row = rows[j]; rows[j] = rows[j - 1]; rows[j - 1] = row;
                        }
                    StringBuilder result = new StringBuilder(TimerSummary(active) + ",[");
                    for (int i = 0; i < rows.Length; i++) { if (i > 0) result.Append("|"); result.Append(rows[i]); }
                    result.Append("]"); return MessageFormat.BuildData(AtGroup, msgId, result.ToString());
                }
                bool wdg = op == "WDG", open = op == "OPEN", start = op == "START", restart = op == "RESTART";
                if (!wdg && !open && !start && !restart && op != "CLOSE" && op != "CANCEL") return Error(msgId, "EOPERATION");
                if ((wdg && args.Length != 4 && args.Length != 5 && args.Length != 7) || (open && (args.Length < 3 || args.Length > 5)) ||
                    (start && (args.Length < 2 || args.Length > 3)) || (restart && (args.Length < 2 || args.Length > 4)) ||
                    ((op == "CLOSE" || op == "CANCEL") && args.Length != 2)) return Error(msgId, "EARGS");
                string key = args[1]; if (!ValidTimerId(key)) return Error(msgId, "EID");
                int delay = 0;
                if (args.Length >= 3 && (!ParseDecimal(args[2], out delay) || delay < 1)) return Error(msgId, "ERANGE");
                string tag = wdg ? (args.Length >= 5 ? args[4] : "") : ((open && args.Length >= 4) || (restart && args.Length == 4) ? args[3] : "");
                if (!ValidTimerTag(tag)) return Error(msgId, "ETAG");
                int period = 0;
                if (open && args.Length == 5 && !ParsePeriod(args[4], out period)) return Error(msgId, "ERANGE");
                string consumer = wdg ? args[3] : "";
                if (wdg && !ValidConsumer(consumer)) return Error(msgId, "ECONSUMER");
                string expectedReply = wdg && args.Length == 7 ? args[5] : "";
                string action = wdg && args.Length == 7 ? args[6] : "";
                if (wdg && ((expectedReply == "") != (action == ""))) return Error(msgId, "ECORRELATION");
                if (wdg && !ValidReply(expectedReply)) return Error(msgId, "EREPLY");
                if (wdg && action != "" && !ValidTimerId(action)) return Error(msgId, "EACTION");
                TimerEntry e = (TimerEntry)namedTimers[key]; string ok = "tmr," + op.ToLower() + "," + key;
                if (op == "CLOSE")
                {
                    if (e == null || (e.PeriodMs > 0 && e.State == "closed")) return Ok(msgId, ok + ",already");
                    e.Run++; e.State = "closed"; e.ExpectedReply = "";
                    if (e.PeriodMs == 0 || !e.Delivering) namedTimers.Remove(key);
                    DisposeTimer(e);
                    ReconcileWatchdogRoutes(msgId); return Ok(msgId, ok);
                }
                if (e != null && e.PeriodMs > 0 && e.State == "closed") return Error(msgId, "EBUSY");
                if (open && e != null) return Ok(msgId, ok + ",already");
                if (e != null && e.PeriodMs > 0 && start && e.State == "active") return Ok(msgId, ok + ",already");
                if (e != null && e.Delivering && !(e.PeriodMs > 0 && op == "CANCEL")) return Error(msgId, "EBUSY");
                if (op == "CANCEL")
                {
                    if (e == null) return Error(msgId, "ENOTFOUND");
                    if (e.State == "idle") return Ok(msgId, ok + ",already");
                    try { if (!e.Timer.Change(Timeout.Infinite, Timeout.Infinite)) throw new InvalidOperationException("Timer.Change returned false"); }
                    catch (Exception ex) { TraceLog(AtGroup, "tmr_cancel", msgId, ex.Message); return Error(msgId, "EPLATFORM"); }
                    e.Run++; e.State = "idle"; ReconcileWatchdogRoutes(msgId); return Ok(msgId, ok);
                }
                if ((start || restart) && e == null) return Error(msgId, "ENOTFOUND");
                if (start && e.State == "active") return Ok(msgId, ok + ",already");
                if (wdg && e != null && e.Type != "WDG") return Error(msgId, "ETYPE");
                if (wdg && e != null && e.State == "active" && e.Consumer != consumer) return Error(msgId, "EBUSY");
                if (!open && !wdg) consumer = e.Consumer;
                if (wdg || (!open && e.Type == "WDG"))
                {
                    string routeError = EnsureWatchdogRoute(consumer, msgId);
                    if (routeError != null) return Error(msgId, routeError);
                }
                try
                {
                    if (e == null) e = AllocateTimer(key);
                    if (e == null) { ReconcileWatchdogRoutes(msgId); return Error(msgId, "ELIMIT"); }
                    if (open) { e.DelayMs = delay; e.Tag = tag; e.Context = msgId; e.PeriodMs = period; return Ok(msgId, ok); }
                    if (args.Length == 2) delay = e.DelayMs;
                    long deadline = timerClock.ElapsedMilliseconds + delay;
                    if (!e.Timer.Change(delay, Timeout.Infinite)) throw new InvalidOperationException("Timer.Change returned false");
                    e.DelayMs = delay; e.Deadline = deadline; e.Context = msgId; e.Run++; e.ExpirationCount = 0; e.State = "active";
                    if (wdg) { e.PeriodMs = 0; e.Type = "WDG"; e.Consumer = consumer; e.Tag = tag; e.ExpectedReply = expectedReply; e.Action = action; }
                    else if (restart && args.Length == 4) e.Tag = tag;
                    ReconcileWatchdogRoutes(msgId); return Ok(msgId, ok);
                }
                catch (Exception ex)
                {
                    if (e != null) { e.State = "closed"; namedTimers.Remove(key); DisposeTimer(e); }
                    ReconcileWatchdogRoutes(msgId); TraceLog(AtGroup, "tmr_arm", msgId, ex.Message); return Error(msgId, "EPLATFORM");
                }
            }
        }
        private static int TimerIdCompare(string a, string b)
        {
            int length = a.Length < b.Length ? a.Length : b.Length;
            for (int i = 0; i < length; i++) if (a[i] != b[i]) return a[i] < b[i] ? -1 : 1;
            return a.Length == b.Length ? 0 : (a.Length < b.Length ? -1 : 1);
        }
    }
}
